#!/usr/bin/env bash
set -euo pipefail
echo "[Bottles] Instalando desde Flathub..."
flatpak install -y flathub com.usebottles.bottles
echo "[Bottles] Ejecuta: flatpak run com.usebottles.bottles"