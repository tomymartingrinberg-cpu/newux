#!/usr/bin/env bash
set -euo pipefail
echo "[Waydroid] Intentando instalar (puede no estar disponible en esta base)..."
apt-get update || true
if ! apt-get install -y waydroid; then
  echo "[Waydroid] Paquete no disponible aquí."
  echo "  Opciones:"
  echo "   1) Android-x86/PrimeOS en otro USB"
  echo "   2) Compilar desde fuente: https://github.com/waydroid/waydroid"
  exit 1
fi
waydroid init || true
systemctl enable waydroid-container || true
systemctl start waydroid-container || true
echo "[Waydroid] Ejecuta: waydroid session start & ; waydroid show-full-ui"