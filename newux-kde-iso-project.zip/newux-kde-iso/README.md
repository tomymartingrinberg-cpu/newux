# Newux (Proyecto de remaster por código, basado en Kubuntu 22.04 LTS)

**Qué hace**  
Genera una ISO Live **Newux** (KDE Plasma) partiendo de **Kubuntu 22.04 LTS Desktop** (Ubiquity installer).  
Incluye:
- **KDE Plasma** (base de Kubuntu) con **Ubiquity** (el mismo instalador de Ubuntu 22.04).
- **Chromium** y **Tor Browser** (vía `torbrowser-launcher`).
- **Wine** + **Flatpak** + lanzador para instalar **Bottles** (GUI de Wine).
- Firmware **Intel iwlwifi** para tu 9462.
- **Persistencia** preparada (boot param `persistent`).
- **Rebranding**: GRUB/menú y etiqueta de la ISO dirán **Newux** en lugar de Ubuntu/Kubuntu.
- Cambios de nombre dentro del sistema (`/etc/lsb-release`, `/etc/os-release`) aplicados al Live.

> Nota: Usamos **Kubuntu 22.04** porque mantiene **Ubiquity** (el instalador clásico de Ubuntu). En 24.04 se usa el nuevo instalador basado en Subiquity y rebrandearlo requiere reconstruir el snap del instalador.

---

## Requisitos (en la máquina de build, Ubuntu/Debian)
```bash
sudo apt update
sudo apt install -y xorriso squashfs-tools genisoimage                     wget rsync chroot debootstrap ubuntu-standard                     grub-pc-bin grub-efi-amd64-bin mtools                     dosfstools parted gdisk                     ca-certificates gnupg
```
> `grub-efi-amd64-bin` asegura reconstrucción EFI. Si falta algún paquete en tu distro, el script lo advertirá.

---

## Pasos rápidos
```bash
sudo ./build_newux.sh
```
El script:
1. Descarga **Kubuntu 22.04.5 LTS** ISO (se puede cambiar URL) y verifica tamaño/sha256 si querés.
2. Monta la ISO, copia su contenido a `iso/`.
3. Extrae `filesystem.squashfs` → `edit/` (filesystem root).
4. Entra al **chroot** y **instala** paquetes (Chromium, torbrowser-launcher, wine, flatpak, firmware-iwlwifi) y configura **Flathub** + **lanzadores**.
5. Cambia **branding** (GRUB/menu, `os-release`, `lsb-release`) a **Newux**.
6. Reconstruye `filesystem.squashfs`, actualiza `manifest`, checksum y **reempaca ISO** con **etiqueta** `NEWUX_22_04_KDE` y `persistent` en los parámetros de arranque.
7. Salida: `newux-22.04-kde.iso`

---

## Persistencia (opcional)
Después de grabar la ISO al USB, crea **otra partición** en el mismo pendrive:
- Tipo: **ext4**
- **Label**: `persistence`
- Crea dentro `persistence.conf` con contenido:
```
/ union
```
Al bootear, con el parámetro `persistent` (ya agregado), **se guardarán** tus cambios.

---

## Archivos del proyecto
- `build_newux.sh` — Script maestro.
- `chroot_stage.sh` — Lo que se ejecuta **dentro** del chroot (instala paquetes y prepara lanzadores).
- `branding/` — Parches de menú GRUB y archivos `/etc/*release`.
- `overlays/` — Lanzadores `.desktop` y scripts (Bottles/Waydroid) que se copian al Live.

---

## Ajustes
- Cambia la URL de descarga si querés otra point-release de 22.04 o una *flavor* diferente.
- Agrega más paquetes KDE (Dolphin, Konsole, Okular) editando `chroot_stage.sh`.
- Si necesitás **Waydroid** realmente funcional, te conviene una base Ubuntu 22.04 instalada (no Live) o Debian 12; aquí queda como lanzador informativo.

Licencia MIT para los scripts.