#!/usr/bin/env bash
set -euo pipefail

export DEBIAN_FRONTEND=noninteractive

echo "[chroot] Actualizando índices..."
apt-get update

echo "[chroot] Instalando paquetes..."
apt-get install -y \
  network-manager wireless-tools wpasupplicant firmware-iwlwifi \
  chromium torbrowser-launcher \
  wine wine32 winetricks \
  flatpak

# Asegurar que NetworkManager gestione redes
systemctl enable NetworkManager || true

# Flathub
echo "[chroot] Configurando Flathub..."
flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo || true

# Lanzadores y scripts ya se copiaron desde overlays/

# Branding dentro del sistema live (aparte del reemplazo del host)
if [ -f /etc/os-release ]; then
  sed -i 's/^NAME=.*/NAME="Newux"/' /etc/os-release || true
  sed -i 's/^PRETTY_NAME=.*/PRETTY_NAME="Newux 22.04 (KDE)"/' /etc/os-release || true
fi
if [ -f /etc/lsb-release ]; then
  sed -i 's/^DISTRIB_ID=.*/DISTRIB_ID=Newux/' /etc/lsb-release || true
  sed -i 's/^DISTRIB_DESCRIPTION=.*/DISTRIB_DESCRIPTION="Newux 22.04 (KDE)"/' /etc/lsb-release || true
fi

echo "[chroot] Limpieza..."
apt-get clean
rm -rf /var/lib/apt/lists/*
echo "[chroot] OK"