#!/usr/bin/env bash
set -euo pipefail

# === Parámetros ===
ISO_URL="${ISO_URL:-https://cdimage.ubuntu.com/kubuntu/releases/22.04.5/release/kubuntu-22.04.5-desktop-amd64.iso}"
ISO_NAME="${ISO_NAME:-kubuntu-22.04.5-desktop-amd64.iso}"
OUT_ISO="${OUT_ISO:-newux-22.04-kde.iso}"
VOLID="${VOLID:-NEWUX_22_04_KDE}"

WORKDIR="$(pwd)"
SRC="${WORKDIR}/src"
ISO_DIR="${WORKDIR}/iso"
EDIT_DIR="${WORKDIR}/edit"
MNT="${WORKDIR}/mnt"

sudo true >/dev/null

cleanup() {
  set +e
  sudo umount "${MNT}/iso" 2>/dev/null || true
  sudo umount "${EDIT_DIR}/proc" 2>/dev/null || true
  sudo umount "${EDIT_DIR}/sys" 2>/dev/null || true
  sudo umount "${EDIT_DIR}/dev/pts" 2>/dev/null || true
  sudo umount "${EDIT_DIR}/dev" 2>/dev/null || true
}
trap cleanup EXIT

mkdir -p "${SRC}" "${ISO_DIR}" "${EDIT_DIR}" "${MNT}/iso"

# 1) Descargar ISO de base
if [ ! -f "${SRC}/${ISO_NAME}" ]; then
  echo "[+] Descargando ${ISO_NAME} ..."
  wget -O "${SRC}/${ISO_NAME}" "${ISO_URL}"
fi

# 2) Montar ISO
echo "[+] Montando ISO..."
sudo mount -o loop "${SRC}/${ISO_NAME}" "${MNT}/iso"

# 3) Copiar contenido a carpeta de trabajo
echo "[+] Copiando contenido de ISO..."
sudo rsync -a --exclude=/casper/filesystem.squashfs "${MNT}/iso/" "${ISO_DIR}/"
sudo unsquashfs -d "${EDIT_DIR}" "${MNT}/iso/casper/filesystem.squashfs"

# 4) Preparar chroot
echo "[+] Preparando chroot..."
sudo mount --bind /dev "${EDIT_DIR}/dev"
sudo mount --bind /dev/pts "${EDIT_DIR}/dev/pts"
sudo mount -t proc /proc "${EDIT_DIR}/proc"
sudo mount -t sysfs /sys "${EDIT_DIR}/sys"

# Copiar nuestros overlays (lanzadores y scripts)
sudo rsync -a overlays/ "${EDIT_DIR}/"

# Branding inicial (os-release/lsb-release en el Live)
sudo rsync -a branding/os-release "${EDIT_DIR}/etc/os-release"
sudo rsync -a branding/lsb-release "${EDIT_DIR}/etc/lsb-release"

# 5) Entrar al chroot y ejecutar stage
echo "[+] Ejecutando chroot stage..."
sudo cp chroot_stage.sh "${EDIT_DIR}/root/chroot_stage.sh"
sudo chroot "${EDIT_DIR}" bash -c "chmod +x /root/chroot_stage.sh && /root/chroot_stage.sh"

# 6) Limpiar chroot
echo "[+] Limpiando chroot..."
sudo chroot "${EDIT_DIR}" bash -c "apt-get clean && rm -rf /var/lib/apt/lists/*"
sudo rm -f "${EDIT_DIR}/root/chroot_stage.sh"

# 7) Desmontar chroot
sudo umount "${EDIT_DIR}/proc"
sudo umount "${EDIT_DIR}/sys"
sudo umount "${EDIT_DIR}/dev/pts"
sudo umount "${EDIT_DIR}/dev"

# 8) Rehacer filesystem.squashfs
echo "[+] Reconstruyendo filesystem.squashfs..."
sudo mksquashfs "${EDIT_DIR}" "${ISO_DIR}/casper/filesystem.squashfs" -b 1048576 -comp xz -Xdict-size 100%

# 9) Actualizar manifest
echo "[+] Actualizando manifest..."
sudo chroot "${EDIT_DIR}" dpkg-query -W --showformat='${Package} ${Version}\n' | sudo tee "${ISO_DIR}/casper/filesystem.manifest" >/dev/null
sudo cp "${ISO_DIR}/casper/filesystem.manifest" "${ISO_DIR}/casper/filesystem.manifest-desktop"
sudo sed -i '/ubiquity/d' "${ISO_DIR}/casper/filesystem.manifest-desktop"
sudo sed -i '/casper/d' "${ISO_DIR}/casper/filesystem.manifest-desktop"

# 10) Branding boot/grub: renombrar entradas a "Newux"
echo "[+] Aplicando branding GRUB..."
if [ -f "${ISO_DIR}/boot/grub/grub.cfg" ]; then
  sudo sed -i 's/Kubuntu/Newux/g; s/Ubuntu/Newux/g' "${ISO_DIR}/boot/grub/grub.cfg"
fi
if [ -f "${ISO_DIR}/isolinux/txt.cfg" ]; then
  sudo sed -i 's/Kubuntu/Newux/g; s/Ubuntu/Newux/g' "${ISO_DIR}/isolinux/txt.cfg"
fi
# Añadir 'persistent' al kernel cmdline
if [ -f "${ISO_DIR}/boot/grub/grub.cfg" ]; then
  sudo sed -i 's/--- quiet/& persistent/' "${ISO_DIR}/boot/grub/grub.cfg" || true
fi
if [ -f "${ISO_DIR}/isolinux/txt.cfg" ]; then
  sudo sed -i 's/--- quiet/& persistent/' "${ISO_DIR}/isolinux/txt.cfg" || true
fi

# 11) Checksums
echo "[+] Actualizando MD5SUMS..."
cd "${ISO_DIR}"
sudo chmod -R u+w .
sudo rm -f md5sum.txt
sudo find . -type f -print0 | sudo xargs -0 md5sum | sudo tee md5sum.txt >/dev/null
cd "${WORKDIR}"

# 12) Desmontar ISO base
sudo umount "${MNT}/iso"

# 13) Reempacar ISO (UEFI+BIOS)
echo "[+] Reempaquetando ISO: ${OUT_ISO} (VOLID=${VOLID})"
xorriso -as mkisofs \
  -r -V "${VOLID}" \
  -o "${OUT_ISO}" \
  -J -l -cache-inodes \
  -isohybrid-mbr "${ISO_DIR}/isolinux/isohdpfx.bin" \
  -partition_offset 16 \
  -b isolinux/isolinux.bin -c isolinux/boot.cat \
     -no-emul-boot -boot-load-size 4 -boot-info-table \
  -eltorito-alt-boot \
  -e boot/grub/efi.img -no-emul-boot -isohybrid-gpt-basdat \
  "${ISO_DIR}"

echo "[+] Listo: ${OUT_ISO}"